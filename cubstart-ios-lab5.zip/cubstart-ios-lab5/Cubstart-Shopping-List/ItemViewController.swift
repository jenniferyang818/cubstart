//
//  ItemViewController.swift
//  Cubstart-Shopping-List
//
//  Created by Alex Lu on 10/11/20.
//  Copyright © 2020 Alexandra Lu. All rights reserved.
//

import UIKit

class ItemViewController: UIViewController {
    
    // IBOutlets have been connected for you :)
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemCount: UILabel!
    
    var count:Int = 0
    var name:String = ""
    var image:String = ""

    // What variables do you need?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set your outlets
        itemName.text = name
        itemCount.text = "Count: \(count)"
        itemImage.image = UIImage(named: image)
    }

}
