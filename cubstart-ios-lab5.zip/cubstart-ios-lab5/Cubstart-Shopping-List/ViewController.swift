//
//  ViewController.swift
//  Cubstart-Shopping-List
//
//  Created by Alex Lu on 10/11/20.
//  Copyright © 2020 Alexandra Lu. All rights reserved.
//

import UIKit

// Create your CustomTableView class and create necessary outlets
class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemNameLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    
}

// Make sure to connect DataSource and Delegate
class ViewController : UIViewController, UITableViewDataSource,UITableViewDelegate {
    
    // Outlets
    @IBOutlet weak var tableView: UITableView!
    
    // Arrays and Variables
    
    let items = [("Apple", 4, "apple.jpeg"), ("Orange", 10, "orange.jpg"), ("Banana", 3, "banana.jpg")]
    var index = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Register your table view
        self.tableView.register(UINib(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "customItems")
        
    }
    
    // UITableViewDataSource functions
    
    // this creates the table
    func tableView( _ tableView:UITableView,
     numberOfRowsInSection section: Int) -> Int {
        return 3// what should this return?
    }
        
    //this tells XCode what we want to populate our cells with
    func tableView( _ tableView:UITableView,
     cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            // create a UITableViewCell; Hint: check out tableView.dequeueReusableCell
            // set cell.textLabel.text to "hello world"
        let cell = tableView.dequeueReusableCell(withIdentifier: "customItems", for: indexPath) as! CustomTableViewCell
        
        
        cell.itemNameLabel.text = items[indexPath.row].0
        cell.countLabel.text = "Count: \(items[indexPath.row].1)"
        cell.itemImage.image = UIImage(named: items[indexPath.row].2)
        
        return cell
    }
    
    // UITableViewDelegate function
    
    func tableView( _ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        index = indexPath.row
        performSegue(withIdentifier: "item", sender: self)
    }

    // Preparing your segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)  {
                if segue.identifier == "item" {
                    let vc: ItemViewController = segue.destination as! ItemViewController
                    vc.name = items[index].0
                    vc.count = items[index].1 
                    vc.image = items[index].2
                }
    }
}

