# cubstart-ios-lab5

Hi everyone! Please clone this repository for Cubstart iOS Lab 5. Use `git clone <URL>`, copying the URL from the green code dropdown. 

## Contributors
- Jojo Chen  
- Rithik Lingineni  
- Abdullahi Aden  
- Alex Lu  
- Saahil Chadha  
